package com.eot_app.nav_menu.jobs.job_detail.reschedule.reschedule_mvp;

/**
 * Created by Mahendra Dabi on 21-08-2020.
 */
public interface Reschedule_PI {

    void  RescheduleJob(RescheduleRequest rescheduleRequest);
}
