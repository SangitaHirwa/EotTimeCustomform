package com.eot_app.nav_menu.custom_fileds.customfield_mvp;

/**
 * Created by Sonam-11 on 14/9/20.
 */
public interface CustomFieldList_View {
    void onSessionExpire(String msg);

    void onSubmitSuccess();
}
