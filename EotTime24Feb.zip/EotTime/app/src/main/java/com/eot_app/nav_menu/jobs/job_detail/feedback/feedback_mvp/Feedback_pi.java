package com.eot_app.nav_menu.jobs.job_detail.feedback.feedback_mvp;


import java.io.File;

public interface Feedback_pi {
    void UploadSignToServer(File path, String DesNotes, String setSmilie, String mParam2);

}
