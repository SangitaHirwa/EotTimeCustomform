package com.eot_app.nav_menu.admin_fw_chat_pkg.chat_pkg.chat_mvp;

import android.graphics.drawable.Drawable;
import android.view.View;

/**
 * Created by Sonam-11 on 2020-03-07.
 */
public interface SingleChat_View {
    void openImage(View thumbView, Drawable bmp, String img_url);
}
