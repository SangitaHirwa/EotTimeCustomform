package com.eot_app.nav_menu.jobs.job_detail.addinvoiveitem2pkg.mvp;

/**
 * Created by Sonam-11 on 10/6/20.
 */
public interface AddEditInvoiceItem_PI {
    void getFwList();

    void getTaxList();

    void getInventryItemList();

    void getJobServiceTittle();

    void getDataFromServer(String search);


}
