package com.eot_app.nav_menu.expense.expense_detail.expense_mvp;

/**
 * Created by Sonam-11 on 7/5/20.
 */
public interface ExpenseDetails_PI {
    void getExpenseDetails(String expId);

    void getExpensehistory(String expId);
}
