package com.eot_app.nav_menu.jobs.job_detail.invoice.invoice_db.item_dao;

import androidx.room.Dao;

/**
 * Created by Sonam-11 on 30/5/20.
 */
@Dao
public interface ItemsDAO {
//    @Insert(onConflict = REPLACE)
//    void insertInvoiceItem(OfflineInvoiceItem itemData);
//
//    @Query("select * from  OfflineInvoiceItem where jobId=:jobId ")
//    List<OfflineInvoiceItem> getItems(String jobId);
//
//    @Query("select * from  OfflineInvoiceItem where jobId=:jobId ")
//    OfflineInvoiceItem getItems2(String jobId);
//
//    @Query("delete from OfflineInvoiceItem where jobId=:jobId or itemData2List IN (:rm)")
//    void deleteJobByIsDelete(String jobId,List<String> rm);


}
