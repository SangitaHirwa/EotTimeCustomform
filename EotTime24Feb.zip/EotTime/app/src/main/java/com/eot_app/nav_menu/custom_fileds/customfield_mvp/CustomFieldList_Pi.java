package com.eot_app.nav_menu.custom_fileds.customfield_mvp;

import com.eot_app.nav_menu.jobs.job_detail.form_form.get_qus_list.ans_model.Ans_Req;

/**
 * Created by Sonam-11 on 14/9/20.
 */
public interface CustomFieldList_Pi {
    void giveAns(Ans_Req ans_req);
}
