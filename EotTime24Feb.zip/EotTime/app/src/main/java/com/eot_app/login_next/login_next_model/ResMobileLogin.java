package com.eot_app.login_next.login_next_model;

public class ResMobileLogin {
    private String isCompInfoFill;
    private String usrId;
    private String compId;
    private String fnm;
    private String lnm;
    private String email;
    private String img;
    private String udId;
    private String username;
    private String token;
    private String cc;
    private String staticLabelFwKeyVal;

    public String getStaticLabelFwKeyVal() {
        return staticLabelFwKeyVal;
    }

    public void setStaticLabelFwKeyVal(String staticLabelFwKeyVal) {
        this.staticLabelFwKeyVal = staticLabelFwKeyVal;
    }

    public String getUsrId() {
        return usrId;
    }

    public String getCompId() {
        return compId;
    }

    public String getFnm() {
        return fnm;
    }

    public String getLnm() {
        return lnm;
    }

    public String getEmail() {
        return email;
    }

    public String getImg() {
        return img;
    }

    public String getUdId() {
        return udId;
    }

    public String getUsername() {
        return username;
    }

    public String getToken() {
        return token;
    }

    public String getCc() {
        return cc;
    }

    public String getIsCompInfoFill() {
        return isCompInfoFill;
    }
}
