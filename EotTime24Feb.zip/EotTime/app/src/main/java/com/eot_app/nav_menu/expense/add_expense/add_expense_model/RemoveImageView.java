package com.eot_app.nav_menu.expense.add_expense.add_expense_model;

/**
 * Created by Sonam-11 on 13/5/20.
 */
public class RemoveImageView {
    String erId;

    public RemoveImageView(String erId) {
        this.erId = erId;
    }
}
