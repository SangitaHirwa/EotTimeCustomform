package com.eot_app.login_next;

/**
 * Created by aplite_pc302 on 1/15/19.
 */

public class FireStoreUserOnlineModel {
    private int online;

    public int getOnline() {
        return online;
    }

    public void setOnline(int online) {
        this.online = online;
    }
}
