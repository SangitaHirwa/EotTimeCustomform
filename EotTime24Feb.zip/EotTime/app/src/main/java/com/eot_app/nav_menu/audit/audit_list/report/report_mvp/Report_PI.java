package com.eot_app.nav_menu.audit.audit_list.report.report_mvp;

import com.eot_app.nav_menu.audit.audit_list.report.mode.ReportRequest;

/**
 * Created by Mahendra Dabi on 13/11/19.
 */
public interface Report_PI {
    void addNewReport(ReportRequest request);

}
