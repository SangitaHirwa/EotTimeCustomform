package com.eot_app.login_next;

/**
 * Created by Sonam-11 on 14/10/20.
 */
public class FooterMenu {
    public String menuField;
    public String odrNo;
    public String isEnable;

    public String getMenuField() {
        return menuField;
    }

    public String getOdrNo() {
        return odrNo;
    }

    public String getIsEnable() {
        return isEnable;
    }

}
