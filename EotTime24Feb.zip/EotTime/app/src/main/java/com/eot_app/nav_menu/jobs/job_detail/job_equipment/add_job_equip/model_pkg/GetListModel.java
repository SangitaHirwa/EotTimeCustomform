package com.eot_app.nav_menu.jobs.job_detail.job_equipment.add_job_equip.model_pkg;

/**
 * Created by Sonam-11 on 30/9/20.
 */
public class GetListModel {
    String limit = "";
    int index;
    String activeRecord = "0";

    public GetListModel() {
        this.index = 0;
    }
}
