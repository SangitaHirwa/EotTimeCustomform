package com.eot_app.nav_menu.jobs.job_detail.invoice.invoice_db.model_pkg;

/**
 * Created by Sonam-11 on 10/6/20.
 */
public class ItembyJobModel {
    String jobId;
   // private String dateTime;

    public ItembyJobModel(String jobId) {//, String dateTime
        this.jobId = jobId;
        // this.dateTime = dateTime;
    }
}
