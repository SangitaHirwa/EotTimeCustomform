package com.eot_app.nav_menu.jobs.job_detail.detail;

public interface NotifyForAttchCount {
void updateCOuntAttchment();
}
