package com.eot_app.nav_menu.report;

public interface LoginReport_view {

    void setData();

    void LoginSuccessFully();
}
