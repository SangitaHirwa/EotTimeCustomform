package com.eot_app.nav_menu.jobs.job_detail.job_equipment.add_job_equip.model_pkg;

public class BrandData {
    private String ebId;
    private String name;

    public String getEbId() {
        return ebId;
    }

    public void setEbId(String ebId) {
        this.ebId = ebId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
