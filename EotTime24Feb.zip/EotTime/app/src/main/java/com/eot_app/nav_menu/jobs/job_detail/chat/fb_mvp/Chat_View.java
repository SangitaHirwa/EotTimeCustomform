package com.eot_app.nav_menu.jobs.job_detail.chat.fb_mvp;

import android.graphics.drawable.Drawable;
import android.view.View;

public interface Chat_View {
    void openImage(View thumbView, Drawable bmp, String img_url);
}
